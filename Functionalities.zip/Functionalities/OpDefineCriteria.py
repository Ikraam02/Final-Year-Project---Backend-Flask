import pypyodbc as odbc  # Import pypyodbc for database operations

class OpDefineCriteria:
    def __init__(self, db_connection):
        self.db_connection = db_connection  # Store the database connection

    def add_criteria(self, data):
        """
        Add a new performance criteria to the PerformanceCriteria table.

        Args:
            data (dict): Contains the criteria_name and description for the new criteria.

        Returns:
            dict: A JSON response with the status and message.
        """
        criteria_name = data.get('criteria_name')
        description = data.get('description')

        # Validate the input data
        if not criteria_name:
            return {"status": "Failure", "message": "Criteria name is required."}

        try:
            cursor = self.db_connection.cursor()

            # Query to insert the new criteria into the PerformanceCriteria table
            query = """
                INSERT INTO PerformanceCriteria (criteria_name, description)
                VALUES (?, ?)
            """
            cursor.execute(query, (criteria_name, description))
            self.db_connection.commit()  # Commit the transaction

            return {"status": "Success", "message": "Criteria added successfully."}

        except odbc.Error as e:
            self.db_connection.rollback()  # Rollback in case of an error
            return {"status": "Failure", "message": f"Error adding criteria: {str(e)}"}
        finally:
            cursor.close()  # Close the cursor
