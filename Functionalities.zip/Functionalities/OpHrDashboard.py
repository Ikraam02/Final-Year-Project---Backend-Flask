import pypyodbc as odbc
import json
from datetime import datetime, timedelta

class OpHrDashboard:
    def __init__(self, db_connection):
        self.db_connection = db_connection

    def get_total_users(self):
        query = "SELECT COUNT(*) AS total_users FROM Users"
        
        try:
            cursor = self.db_connection.cursor()
            cursor.execute(query)
            result = cursor.fetchone()
            total_users = result[0] if result else 0
            cursor.close()
            return {"status": "Success", "total_users": total_users}
        except odbc.Error as e:
            print("Database query error:", e)
            return {"status": "Failure", "message": "Error fetching total users."}


    def get_employees_on_leave_today(self):
        today = datetime.now().date()
        query = """
            SELECT COUNT(DISTINCT employee_id) AS employees_on_leave
            FROM LeaveApplications
            WHERE status = 'Approved'
            AND start_date <= ?
            AND end_date >= ?
        """
        
        try:
            cursor = self.db_connection.cursor()
            cursor.execute(query, (today, today))
            result = cursor.fetchone()
            employees_on_leave = result[0] if result else 0
            cursor.close()
            return {"status": "Success", "employees_on_leave_today": employees_on_leave}
        except odbc.Error as e:
            print("Database query error:", e)
            return {"status": "Failure", "message": "Error fetching employees on leave today."}


    def get_total_net_salary_previous_month(self):
        # Calculate the first and last day of the previous month
        today = datetime.now()
        first_day_current_month = today.replace(day=1)
        last_day_previous_month = first_day_current_month - timedelta(days=1)
        first_day_previous_month = last_day_previous_month.replace(day=1)
        
        query = """
            SELECT SUM(net_salary) AS total_net_salary
            FROM Payrolls
            WHERE payroll_date >= ? AND payroll_date <= ?
        """
        
        try:
            cursor = self.db_connection.cursor()
            cursor.execute(query, (first_day_previous_month, last_day_previous_month))
            result = cursor.fetchone()
            total_net_salary = round(result[0]) if result and result[0] else 0
            cursor.close()
            return {"status": "Success", "total_net_salary_previous_month": total_net_salary}
        except odbc.Error as e:
            print("Database query error:", e)
            return {"status": "Failure", "message": "Error fetching total net salary for previous month."}


    def get_total_employees_clocked_in_today(self):
        today = datetime.now().date()
        query = """
            SELECT COUNT(DISTINCT employee_id) AS total_clocked_in
            FROM Attendance
            WHERE date = ? AND clock_in_time IS NOT NULL
        """
        
        try:
            cursor = self.db_connection.cursor()
            cursor.execute(query, (today,))
            result = cursor.fetchone()
            total_clocked_in = result[0] if result else 0
            cursor.close()
            return {"status": "Success", "total_employees_clocked_in_today": total_clocked_in}
        except odbc.Error as e:
            print("Database query error:", e)
            return {"status": "Failure", "message": "Error fetching total employees clocked in today."}


    def get_percentage_of_employees_in_departments(self):
        departments = {
            "Information Technology": "percentage_information_technology",
            "Human Resource": "percentage_human_resource",
            "Quality Assurance": "percentage_quality_assurance"
        }
        
        query_total_users = "SELECT COUNT(*) FROM Users"
        query_department_users = """
            SELECT r.description, COUNT(*)
            FROM Users u
            JOIN Roles r ON u.role_id = r.role_id
            WHERE r.description IN (?, ?, ?)
            GROUP BY r.description
        """
        
        try:
            cursor = self.db_connection.cursor()
            
            # Fetch total number of users
            cursor.execute(query_total_users)
            total_users = cursor.fetchone()[0] if cursor.fetchone() else 0
            
            if total_users == 0:
                return {"status": "Failure", "message": "No users found."}
            
            # Fetch the number of users in the specified departments
            cursor.execute(query_department_users, tuple(departments.keys()))
            department_results = cursor.fetchall()
            
            cursor.close()

            # Initialize percentages for each department
            percentage_results = {
                "percentage_information_technology": 0,
                "percentage_human_resource": 0,
                "percentage_quality_assurance": 0
            }
            
            # Calculate percentages based on department results
            for row in department_results:
                department = row[0]
                count = row[1]
                percentage = (count / total_users) * 100
                percentage_results[departments[department]] = round(percentage, 2)
            
            return {
                "status": "Success",
                **percentage_results
            }
        
        except odbc.Error as e:
            print("Database query error:", e)
            return {"status": "Failure", "message": "Error fetching department percentage."}
